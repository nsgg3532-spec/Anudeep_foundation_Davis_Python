def tuple_to_dict(keys, values):
    # validation
    if len(keys) != len(values):
        print("Error: Length mismatch")
        return {}

    result = {}

    for i in range(len(keys)):
        result[keys[i]] = values[i]

    return result

keys = ('a', 'b', 'c')
values = (1, 2, 3)

print("Dictionary:", tuple_to_dict(keys, values))