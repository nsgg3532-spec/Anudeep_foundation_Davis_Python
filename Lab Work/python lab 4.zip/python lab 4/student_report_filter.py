# Program to filter students with marks > 75

try:
    file = open(r"C:\python\advance python\python lab 4\students.txt", "r")
    output = open("top_students.txt", "w")

    for line in file:
        # removing extra spaces/newline
        line = line.strip()

        # skip empty lines
        if line == "":
            continue

        # splitting data
        name, marks, city = line.split(",")

        if int(marks) > 75:
            output.write(line + "\n")

    print("Filtered data saved successfully!")

    file.close()
    output.close()

except FileNotFoundError:
    print("students.txt file not found!")