import os

file_path = os.path.join(os.path.dirname(__file__), "attendance.txt")

print("Reading from:", file_path)

attendance = {}

try:
    with open(file_path, "r") as f:
        print("File opened")

        for line in f:
            print("Line:", line)   # DEBUG

            try:
                emp_id, date, status = line.strip().split(",")

                if emp_id not in attendance:
                    attendance[emp_id] = {"P": 0, "A": 0}

                if status == "P":
                    attendance[emp_id]["P"] += 1
                elif status == "A":
                    attendance[emp_id]["A"] += 1

            except:
                print("Invalid line:", line)

    print("Final Data:", attendance)

    for emp in attendance:
        present = attendance[emp]["P"]
        absent = attendance[emp]["A"]
        total = present + absent

        percent = (present / total) * 100

        print(f"Employee {emp}: {percent:.2f}%")

        if percent < 75:
            print("Low attendance:", emp)

except FileNotFoundError:
    print("File not found")