import os

# file path (same folder)
file_path = os.path.join(os.path.dirname(__file__), "inventory.txt")

inventory = {}

# 🔹 Load data from file
def load_inventory():
    try:
        with open(file_path, "r") as f:
            for line in f:
                line = line.strip()
                if line == "":
                    continue
                
                name, qty = line.split(",")
                inventory[name] = int(qty)

        print("Inventory loaded successfully")

    except FileNotFoundError:
        print("No existing file, starting fresh")


# 🔹 Save data to file
def save_inventory():
    with open(file_path, "w") as f:
        for name, qty in inventory.items():
            f.write(f"{name},{qty}\n")

    print("Inventory saved successfully")


# 🔹 Add item
def add_item():
    name = input("Enter item name: ")
    qty = int(input("Enter quantity: "))

    inventory[name] = inventory.get(name, 0) + qty
    print("Item added/updated")


# 🔹 Update item
def update_item():
    name = input("Enter item name to update: ")

    if name in inventory:
        qty = int(input("Enter new quantity: "))
        inventory[name] = qty
        print("Item updated")
    else:
        print("Item not found")


# 🔹 Delete item
def delete_item():
    name = input("Enter item name to delete: ")

    if name in inventory:
        del inventory[name]
        print("Item deleted")
    else:
        print("Item not found")


# 🔹 Display inventory
def display():
    print("\nCurrent Inventory:")
    for name, qty in inventory.items():
        print(name, ":", qty)


# 🔹 Main Menu
def menu():
    load_inventory()

    while True:
        print("\n1. Add Item")
        print("2. Update Item")
        print("3. Delete Item")
        print("4. Display")
        print("5. Save & Exit")

        choice = input("Enter choice: ")

        if choice == "1":
            add_item()
        elif choice == "2":
            update_item()
        elif choice == "3":
            delete_item()
        elif choice == "4":
            display()
        elif choice == "5":
            save_inventory()
            print("Exiting...")
            break
        else:
            print("Invalid choice")


# Run program
menu()