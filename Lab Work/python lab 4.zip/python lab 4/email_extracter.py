# Program to extract email addresses

import re

try:
    file = open(r"C:\python\advance python\python lab 4\data.txt", "r")
    text = file.read()

    # regex pattern for email
    emails = re.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]+", text)

    output = open("emails.txt", "w")

    for email in emails:
        output.write(email + "\n")

    print("Emails extracted successfully!")

    file.close()
    output.close()

except FileNotFoundError:
    print("data.txt not found!")