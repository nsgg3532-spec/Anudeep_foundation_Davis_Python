#----------------------------------------------------------
#Student Result Analyzer
#---------------------------------------------------------

#Step 1 : import csv is use for split the commas seprate data
import csv

#Step 2 : handle the exception
try:
    #here use "with" that not need close method
 with open(r"C:\python\advance python\python question\students.txt", "r") as f:

    #Step 3 : read row wise and every line make list -> [101,"Rahul",85,90,88]
        reader = csv.reader(f)
        
        topper = ("", 0) #name,marks that is blank
        #Step 4 : Loop run at every row and rows in the form of list
        for row in reader:
            try:
                # list break into variable -> ["101","Rahul","85","90","88"]
                id, name, m1, m2, m3 = row    #this are file data

                #String → integer conversion because we want math operation
                m1, m2, m3 = int(m1), int(m2), int(m3)
                
                total = m1 + m2 + m3
                percent = total / 3
                
                if percent >= 90:
                    grade = "A"
                elif percent >= 75:
                    grade = "B"
                else:
                    grade = "C"
                
                print(name, total, percent, grade)
                
                if total > topper[1]: #topper[1] = marks
                    topper = (name, total)
                    
            except:
                print("Invalid data:", row)
        
        print("Topper:", topper)

except FileNotFoundError:
    print("File not found")