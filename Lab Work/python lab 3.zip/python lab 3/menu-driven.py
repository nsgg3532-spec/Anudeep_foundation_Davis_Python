# main_program.py
# This program uses geometry_module to perform operations

import geometry_module as gm

while True:
    print("\n------ SELECT SHAPE ------")
    print("1. Cube")
    print("2. Cuboid")
    print("3. Cylinder")
    print("4. Cone")
    print("5. Sphere")
    print("6. Exit")

    choice = input("Enter your choice: ")

    if choice == '6':
        print("Exiting program...")
        break

    # ---------------- OPERATION MENU ----------------
    print("\n--- Select Operation ---")
    print("1. Curved Surface Area")
    print("2. Total Surface Area")
    print("3. Volume")

    op = input("Enter operation: ")

    # ---------------- CUBE ----------------
    if choice == '1':
        side = float(input("Enter side: "))

        if side <= 0:
            print("Invalid input!")
            continue

        if op == '1':
            print("CSA:", gm.cube_csa(side))
        elif op == '2':
            print("TSA:", gm.cube_tsa(side))
        elif op == '3':
            print("Volume:", gm.cube_volume(side))

    # ---------------- CUBOID ----------------
    elif choice == '2':
        l = float(input("Enter length: "))
        b = float(input("Enter breadth: "))
        h = float(input("Enter height: "))

        if l <= 0 or b <= 0 or h <= 0:
            print("Invalid input!")
            continue

        if op == '1':
            print("CSA:", gm.cuboid_csa(l, b, h))
        elif op == '2':
            print("TSA:", gm.cuboid_tsa(l, b, h))
        elif op == '3':
            print("Volume:", gm.cuboid_volume(l, b, h))

    # ---------------- CYLINDER ----------------
    elif choice == '3':
        r = float(input("Enter radius: "))
        h = float(input("Enter height: "))

        if r <= 0 or h <= 0:
            print("Invalid input!")
            continue

        if op == '1':
            print("CSA:", gm.cylinder_csa(r, h))
        elif op == '2':
            print("TSA:", gm.cylinder_tsa(r, h))
        elif op == '3':
            print("Volume:", gm.cylinder_volume(r, h))

    # ---------------- CONE ----------------
    elif choice == '4':
        r = float(input("Enter radius: "))
        h = float(input("Enter height: "))
        l = float(input("Enter slant height: "))

        if r <= 0 or h <= 0 or l <= 0:
            print("Invalid input!")
            continue

        if op == '1':
            print("CSA:", gm.cone_csa(r, l))
        elif op == '2':
            print("TSA:", gm.cone_tsa(r, l))
        elif op == '3':
            print("Volume:", gm.cone_volume(r, h))

    # ---------------- SPHERE ----------------
    elif choice == '5':
        r = float(input("Enter radius: "))

        if r <= 0:
            print("Invalid input!")
            continue

        if op == '1':
            print("CSA:", gm.sphere_csa(r))
        elif op == '2':
            print("TSA:", gm.sphere_tsa(r))
        elif op == '3':
            print("Volume:", gm.sphere_volume(r))

    else:
        print("Invalid choice! Please try again.")