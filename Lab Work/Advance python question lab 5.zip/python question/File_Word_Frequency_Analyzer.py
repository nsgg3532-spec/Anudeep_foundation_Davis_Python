stop_words = {"the", "is", "and", "in"}

with open(r"C:\python\advance python\python question\file.txt", "r") as f:
    text = f.read().lower().split()

freq = {}

for word in text:
    if word not in stop_words:
        freq[word] = freq.get(word, 0) + 1

top_words = sorted(freq.items(), key=lambda x: x[1], reverse=True)[:10]

print(top_words)