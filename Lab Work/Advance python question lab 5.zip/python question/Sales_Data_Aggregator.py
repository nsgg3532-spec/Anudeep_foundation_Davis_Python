data = [
    ("Laptop", "Electronics", 50000, 2),
    ("Phone", "Electronics", 20000, 3),
    ("Shirt", "Clothing", 1000, 5)
]

category_sales = {}
max_product = ("", 0)

for name, cat, price, qty in data:
    total = price * qty

    category_sales[cat] = category_sales.get(cat, 0) + total

    if total > max_product[1]:
        max_product = (name, total)

print(category_sales)
print(max_product)