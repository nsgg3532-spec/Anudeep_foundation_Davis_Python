logs = [
    "INFO start",
    "ERROR failed",
    "ERROR failed",
    "INFO end"
]

unique_logs = set(logs)   # remove duplicates

count = 0

for log in unique_logs:
    if "ERROR" in log:
        print(log)
        count += 1

print("Error count:", count)