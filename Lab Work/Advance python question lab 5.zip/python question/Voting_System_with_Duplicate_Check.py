#--------------------------------------------
#--------------Voting system-----------------
#step 1: Creat a list of vote
votes = ["A", "B", "A", "C", "B", "A"]

#Step 2: create a set for remove duplicate vale
unique_voters = set()

#Dictionary to count votes
vote_count = {}

#Step 3: run loop at every vote
for vote in votes:
    if vote not in unique_voters: #if pahle vote nahi hua 
        unique_voters.add(vote) #add to set
        vote_count[vote] = vote_count.get(vote, 0) + 1 #if vote is not exist → 0 then +1
#Step 3: higher value is winner
winner = max(vote_count, key=vote_count.get)

print(vote_count)
print("Winner:", winner)