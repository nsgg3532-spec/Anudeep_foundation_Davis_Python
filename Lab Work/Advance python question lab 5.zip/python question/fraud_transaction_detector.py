transactions = [
    ("user1", 5000),
    ("user1", 12000),
    ("user2", 20000),
    ("user2", 300)
]

threshold = 10000
flagged = {}

for user, amount in transactions:
    if amount > threshold:
        flagged[user] = flagged.get(user, 0) + 1

print(flagged)