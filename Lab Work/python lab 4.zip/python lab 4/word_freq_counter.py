# Program to count word frequency

import string

try:
    file = open(r"C:\python\advance python\python lab 4\article.txt", "r")
    text = file.read().lower()   # convert to lowercase

    # remove punctuation
    for ch in string.punctuation:
        text = text.replace(ch, "")

    words = text.split()
    freq = {}

    # counting words
    for word in words:
        if word in freq:
            freq[word] += 1
        else:
            freq[word] = 1

    print("Word Frequency:")
    for k, v in freq.items():
        print(k, ":", v)

    file.close()

except FileNotFoundError:
    print("article.txt not found!")